using System.Collections;
using System.Collections.Generic;
using DefaultNamespace;
using UnityEngine;

public class BunnyCollider : MonoBehaviour
{
    public GameObject westWall, floor;
    public AudioSource rabbitWall;
    public AudioSource rabbitPerson; 
   
    private void OnTriggerEnter(Collider other)
    {
        if (other.name != westWall.name & other.name != floor.name)
        {
            Controller.Instance.moveTarget = false;
            Controller.Instance.target.transform.position = new Vector3(-5000.0f, 0f, 0f);
            Debug.Log(other.name);
            Controller.Instance.currentTrial++;

            if (other.name == "FirstPerson-AIO"){
                Controller.Instance.intercepted = true;
                rabbitPerson.Play();
                Controller.Instance.interceptedButton.interactable = true; 
            }
            else
            {
                Controller.Instance.missedButton.interactable = true; 
                rabbitWall.Play();
            }
        }
    }
    
}
