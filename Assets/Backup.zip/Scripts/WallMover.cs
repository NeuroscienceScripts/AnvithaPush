using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallMover : MonoBehaviour
{
    [SerializeField] private GameObject eastWall, westWall, southWall, northWall; 
    // Start is called before the first frame update
    private void Start()
    {
        eastWall.transform.localScale = new Vector3(1.0f, 8.0f, Controller.Instance.northSouthWallBoundary-1); 
        westWall.transform.localScale = new Vector3(1.0f, 8.0f, Controller.Instance.northSouthWallBoundary-1); 
        eastWall.transform.position = new Vector3((Controller.Instance.eastWestWallBoundary / 2.0f) + 0.5f,4,0);
        westWall.transform.position = new Vector3(-(Controller.Instance.eastWestWallBoundary / 2.0f) - 0.5f, 4, 0);
        northWall.transform.position = new Vector3(0, 4, (Controller.Instance.northSouthWallBoundary / 2.0f) + 0.5f); 
        southWall.transform.position = new Vector3(0, 4, -(Controller.Instance.northSouthWallBoundary / 2.0f) - 0.5f);
    }

}
