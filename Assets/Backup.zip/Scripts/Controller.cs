using System;
using System.Diagnostics;
using System.IO;
using DefaultNamespace;
using TMPro;
using Unity.VisualScripting.FullSerializer;
using UnityEngine;
using UnityEngine.UI;
using Valve.VR;
using Debug = UnityEngine.Debug;
using Random = UnityEngine.Random;

public class Controller : MonoBehaviour
{
  public static Controller Instance { get; private set; }
  [Header("Experiment Settings")] 
  public bool debugMode; 
  public bool vrMode; 
  public float northSouthWallBoundary;
  public float eastWestWallBoundary;
  public float targetSpeed = 1.0f;
  public Vector2 startingPos; 
  public float linearSlope = 0.5f;
  public float piecewiseSlope = 0.25f;
  public Vector3 piecewiseStarts = new Vector3(2.0f, 4.0f, 6.0f);
  public float curveIntensity = 3; 
  public int currentPath = 0;
  public bool invisibility;
  public Vector4 invisibilityIntervals = new Vector4(0, 3, 10, 10); 
  
  [Header("Don't change these")]
  public GameObject target;
  public InputField subjectNumber;
  public InputField trialNumber;
  public Button readyButton;
  public Button interceptedButton;
  public Button missedButton;
  public GameObject playerPosText;
  public GameObject currentTrialText; 
  public bool moveTarget;
  public GameObject rabbitMesh;
  public GameObject rabbitEyesMesh;
  public GameObject startingPoint;
  public Camera mainCamera;
  public GameObject firstPerson;

  
  private FileHandler fileHandler = new FileHandler();
  private float recordInterval;
  private bool started = false; 
  private string filePath;
  private float startTime;
  private Vector3 piecewiseTracker = new Vector3(0, 0, 0);
  Vector2 piecewiseStart = new Vector2(0, 0); 
  private float lastAngle = (float) Math.PI/2.0f;
  private float invisibilityTime;
  public bool intercepted = false; 
  
  public int currentTrial = 0; 
  private int[] paths = {0, 0, 0, 1, 2, 3, 1, 2, 3, 1, 2, 3};
  private int[] invisSettings = {1, 2, 3, 1, 1, 1, 2, 2, 2, 3, 3, 3};

  private void Start()
  {
    for (int t = 3; t < paths.Length; t++)
    {
      int tmp = paths[t];
      int tmpInvis = invisSettings[t]; 

      int r = Random.Range(t,paths.Length);
      paths[t] = paths[r];
      paths[r] = tmp;
      invisSettings[t] = invisSettings[r];
      invisSettings[r] = tmpInvis;
    }
  }
  
  private void LinearPath(Vector2 startPos, float slope)
  {
    float elapsedTime = Time.time - startTime; 
    float directionMagnitude = (float) Math.Sqrt(Math.Pow(slope, 2) + 1);
    Debug.Log("StartPos: "+startPos); 
    Vector3 currentPosition = target.transform.position; 
    Vector3 nextPosition = new Vector3(startPos.x + (elapsedTime * targetSpeed / directionMagnitude),
      currentPosition.y, startPos.y + (elapsedTime * targetSpeed * slope / directionMagnitude));
    
    float newAngle = (float) Math.Atan((nextPosition.x - currentPosition.x) / 
                                       Math.Sqrt(Math.Pow(nextPosition.z - currentPosition.z, 2)));
    newAngle = slope < 0 ? (float) Math.PI - newAngle : newAngle;

    lastAngle = newAngle; 
    target.transform.eulerAngles = new Vector3(0.0f, newAngle * 180.0f/(float)Math.PI, 0.0f);
    
    target.transform.position = nextPosition;
  }
  
  private void WalkPath()
  {
    switch (debugMode ? currentPath : paths[currentTrial])
    {
      case (0): //Practice Trial
        LinearPath(startingPos,0);
        break;
      
      case (1): //Linear
        LinearPath(startingPos, linearSlope);
        break;

      case (2): //Piecewise
        if (target.transform.position.x < piecewiseStarts.x & piecewiseTracker.x==0)
        {
          LinearPath(piecewiseStart, piecewiseSlope);
        }
        else if (target.transform.position.x < piecewiseStarts.y & piecewiseTracker.y==0)
        {
          if (piecewiseTracker.x == 0)
          {
            piecewiseStart.x = target.transform.position.x;
            piecewiseStart.y = target.transform.position.z; 
            piecewiseTracker.x = 1;
            startTime = Time.time;

          }
          LinearPath(piecewiseStart, -1.0f * piecewiseSlope);
        }
        else if (target.transform.position.x < piecewiseStarts.z & piecewiseTracker.z==0)
        {
          if (piecewiseTracker.y == 0)
          {
            piecewiseStart.x = target.transform.position.x;
            piecewiseStart.y = target.transform.position.z; 
            piecewiseTracker.y = 1;
            startTime = Time.time;

          }
          LinearPath(piecewiseStart, 1.0f * piecewiseSlope);
        }
        else
        {
          if (piecewiseTracker.z == 0)
          {
            piecewiseStart.x = target.transform.position.x;
            piecewiseStart.y = target.transform.position.z; 
            piecewiseTracker.z = 1;
            startTime = Time.time;

          }
          LinearPath(piecewiseStart, -1.0f * piecewiseSlope);
        }
        break; 
      
      case(3): //curved
          LinearPath(startingPos, -1.0f * (curveIntensity/10.0f) * (Time.time-startTime) );
        break; 
    }
    
  }

  private void Update()
  {
    currentTrialText.GetComponent<TextMeshProUGUI>().text = "Current trial: " + currentTrial; 
    if (currentTrial < paths.Length)
    {
      startingPoint.transform.position =
        new Vector3(startingPos.x - 3.0f, startingPoint.transform.position.y, startingPos.y);

      if (Input.GetKeyDown(KeyCode.Backspace) && currentTrial > 0)
        currentTrial--;

      if (started)
      {
        subjectNumber.interactable = false;
        trialNumber.interactable = false;
        readyButton.interactable = true;

        playerPosText.GetComponent<TextMeshProUGUI>().text = firstPerson.transform.position.x + ",\n" +
                             firstPerson.transform.position.y + ",\n" + firstPerson.transform.position.z + ",\n" +
                             mainCamera.transform.rotation.x + ",\n" + mainCamera.transform.rotation.y + ",\n" +
                             mainCamera.transform.rotation.z;
        if (moveTarget)
          WalkPath();
        else if (Input.GetKeyDown(KeyCode.Space)) // || SteamVR_Actions._default.GrabPinch.GetStateDown(SteamVR_Input_Sources.Any))
        {
          if (StartCheck.Instance.ready)
          {
            piecewiseStart = startingPos;
            target.transform.position = new Vector3(startingPos.x - 3.0f, target.transform.position.y, startingPos.y);
            target.transform.eulerAngles = new Vector3(0.0f, 90.0f, 0.0f);
            startTime = Time.time;
            rabbitMesh.GetComponent<SkinnedMeshRenderer>().enabled = true;
            rabbitEyesMesh.GetComponent<SkinnedMeshRenderer>().enabled = true;

          }
        }
        else if (target.transform.position.x >= startingPos.x)
        {
          if (StartCheck.Instance.ready)
          {
            piecewiseTracker.x = piecewiseTracker.y = piecewiseTracker.z = 0;
            moveTarget = true;
            startTime = Time.time;
            fileHandler.AppendLine(filePath.Replace(".csv", "_intercepted.csv"),
              paths[currentTrial] + "," + invisSettings[currentTrial] + "," + intercepted.ToString());
            intercepted = false;
            interceptedButton.interactable = false;
            missedButton.interactable = false;
          }
          else
          {
            target.transform.position = new Vector3(-5000.0f, 0f, 0f);
          }
        }
        else
        {
          target.transform.position = new Vector3(target.transform.position.x + targetSpeed * (Time.time - startTime),
            target.transform.position.y, startingPos.y);
          startTime = Time.time;
        }
      }
      else if (Input.GetKeyDown(KeyCode.Return))
      {
        filePath = Application.dataPath + Path.DirectorySeparatorChar + "Data" + Path.DirectorySeparatorChar +
                   subjectNumber.text + ".csv";
        fileHandler.AppendLine(filePath, DateTime.Now.ToString());
        fileHandler.AppendLine(filePath.Replace(".csv", "_intercepted.csv"), DateTime.Now.ToString());
        started = true;
        try
        {
          currentTrial = Int32.Parse(trialNumber.text) -1;
        }
        catch (Exception e)
        {
          Debug.Log("Default trial = 0");
          currentTrial = 0; 
          Debug.Log(e);
          throw;
        }
        try
        {
          int parseNumber = Int32.Parse(subjectNumber.text);
          Random.InitState(parseNumber * 10);
        }
        catch (Exception e)
        {
          filePath = Application.dataPath + Path.DirectorySeparatorChar + "Data" + Path.DirectorySeparatorChar +
                      "no_subject.csv";
          fileHandler.AppendLine(filePath, DateTime.Now.ToString());
          fileHandler.AppendLine(filePath.Replace(".csv", "_intercepted.csv"), DateTime.Now.ToString());
          Debug.Log(e);
          throw;
        }

      }

      Debug.Log(currentTrial);
      Debug.Log(invisSettings[currentTrial]);
      if (invisSettings[currentTrial] == 2 & target.transform.position.x >= startingPos.x)
      {
        if (target.transform.position.x < invisibilityIntervals.x)
        {
          rabbitMesh.GetComponent<SkinnedMeshRenderer>().enabled = true;
          rabbitEyesMesh.GetComponent<SkinnedMeshRenderer>().enabled = true;
        }
        else if (target.transform.position.x < invisibilityIntervals.y)
        {
          rabbitMesh.GetComponent<SkinnedMeshRenderer>().enabled = false;
          rabbitEyesMesh.GetComponent<SkinnedMeshRenderer>().enabled = false;
        }
        else if (target.transform.position.x < invisibilityIntervals.z)
        {
          rabbitMesh.GetComponent<SkinnedMeshRenderer>().enabled = true;
          rabbitEyesMesh.GetComponent<SkinnedMeshRenderer>().enabled = true;
        }
        else
        {
          rabbitMesh.GetComponent<SkinnedMeshRenderer>().enabled = false;
          rabbitEyesMesh.GetComponent<SkinnedMeshRenderer>().enabled = false;
        }
      }

      if (invisSettings[currentTrial] == 3 & target.transform.position.x >= invisibilityIntervals.x)
      {
        rabbitMesh.GetComponent<SkinnedMeshRenderer>().enabled = false;
        rabbitEyesMesh.GetComponent<SkinnedMeshRenderer>().enabled = false;
      }

      if (moveTarget & Time.time - recordInterval > .1)
      {
        fileHandler.AppendLine(filePath, Time.time-startTime + "," + paths[currentTrial]+","+
          invisSettings[currentTrial] + "," +firstPerson.transform.position.x + "," +
          firstPerson.transform.position.y + "," + firstPerson.transform.position.z + "," + 
          mainCamera.transform.rotation.x + "," + mainCamera.transform.rotation.y + "," + 
          mainCamera.transform.rotation.z );
        recordInterval = Time.time; 
      }
    }
  }
  
  private void Awake()
  {
    if ( Instance == null)
    {
      Instance = this;
      DontDestroyOnLoad(gameObject);
    }
  }
}
