﻿using System;
using UnityEngine;
using UnityEngine.Video;

namespace DefaultNamespace
{
    public class StartCheck : MonoBehaviour
    {
        public static StartCheck Instance { get; private set; }
        public bool ready=true;
        public GameObject startingSphere; 
        
        // private void OnTriggerEnter(Collider other)
        // {
        //     if (other.name == startingSphere.name)
        //     {
        //         Debug.Log("Ready");
        //         ready = true;
        //     }
        // }

        // private void OnTriggerStay(Collider other)
        // {
        //     if (other.name == startingSphere.name)
        //         ready = true;
        //     else
        //         ready = false; 
        // }

        // private void OnTriggerExit(Collider other)
        // {
        //     if (other.name == startingSphere.name)
        //         ready = false; 
        // }
        
        private void Awake()
        {
            if ( Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
            }
        }
    }
}