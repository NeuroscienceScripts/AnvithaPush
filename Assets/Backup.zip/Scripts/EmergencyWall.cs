using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class EmergencyWall : MonoBehaviour
{
    public bool westWall = false;
    public AudioSource personWall; 
    
    private void OnTriggerEnter(Collider other)
    {
        if (!westWall || other.name != "Rabbit")
        {
            gameObject.GetComponent<MeshRenderer>().enabled = true;
            Debug.Log(other.name);
            
        }
        personWall.Play();
    }
    private void OnTriggerExit(Collider other)
    {
        gameObject.GetComponent<MeshRenderer>().enabled = false; 
    }
}
